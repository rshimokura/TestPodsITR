//
//  LibITR.h
//  LibITR
//
//  Created by Shimokura on 2023/09/07.
//

#import <Foundation/Foundation.h>

//! Project version number for LibITR.
FOUNDATION_EXPORT double LibITRVersionNumber;

//! Project version string for LibITR.
FOUNDATION_EXPORT const unsigned char LibITRVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LibITR/PublicHeader.h>


